
// ====================================================================================================
// Form
// ====================================================================================================
const Form = {
   showAlert : function(arg) {
          this.msgBox(arg, function(result) {
      });
   },    
   // 공통 Dialog 메시지  
   msgBox : function(arg, callback) {
    
    $form.openDialog('10_Logic_and_Scripting/shared_popup', arg, callback);
      
     
  }

};